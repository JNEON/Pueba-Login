﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using User1.Data;
using User1.Logic;

namespace User1.Vista
{
    public partial class Usuarios : Form
    {
        public Usuarios()
        {
            InitializeComponent();
        }

        int idusuario;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panelUsuario.Visible = true;
            panelUsuario.Dock = DockStyle.Fill;
            btnGuardar.Visible = true;
            btnAct.Visible = false;
            tLogin.Clear();
            tPass.Clear();
        }

        private void Usuarios_Load(object sender, EventArgs e)
        {
            mostrar_usuarios();
        }

        private void lLogin_Click(object sender, EventArgs e)
        {
            lLogin.Visible = false;
        } 

        private void lPass_Click(object sender, EventArgs e)
        {
            lPass.Visible = false;
        }

        private void Usuario_TextChanged(object sender, EventArgs e)
        {
            lLogin.Visible = false;
        }

        private void tPass_TextChanged(object sender, EventArgs e)
        {
            lPass.Visible = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            lImage.Visible = false;
            dlg .InitialDirectory = "";
            dlg.Filter = "Imagenes|*.jpg;*.png";
            dlg.FilterIndex = 2;
            dlg.Title = "Cargador de Imagenes";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                Imagen.BackgroundImage = null;
                Imagen.Image = new Bitmap(dlg.FileName);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (tLogin.Text != "")
            {
                if (tPass.Text != "")
                {
                    insertar_usuario(); 
                    mostrar_usuarios();
                }
                else
                {
                    MessageBox.Show("Ingrese una Contraseña", "Sin Contraseña", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ingrese un Usuario", "Sin Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void insertar_usuario()
        {
            Lusers dt = new Lusers();
            Dusers funcion = new Dusers();
            dt.Usuario = tLogin.Text;
            dt.Pass = tPass.Text;
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            Imagen.Image.Save(ms, Imagen.Image.RawFormat);
            dt.Icono = ms.GetBuffer();
            dt.Estado = "ACTIVO";
            if (funcion.insertar(dt))
            {
                MessageBox.Show("Usuario Registrado", "Registro Correcto");
                panelUsuario.Visible = false;
                panelUsuario.Dock = DockStyle.None;
            }
        }

        private void tBusqueda_TextChanged(object sender, EventArgs e)
        {
            buscar_usuarios();
        }

        private void buscar_usuarios()
        {
            DataTable dt;
            Dusers funcion = new Dusers();
            dt = funcion.buscar_usuarios(tBusqueda.Text);
            Grid.DataSource = dt;
        }

        private void eliminar_usuarios()
        {
            Lusers dt = new Lusers();
            Dusers funcion = new Dusers();
            dt.Idusuario = idusuario;
            if (funcion.eliminar(dt))
            {
                MessageBox.Show("Usuario eliminado", "Eliminacion Correcta");
                panelUsuario.Visible = false;
                panelUsuario.Dock = DockStyle.None;
            }
        }

        private void Grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            idusuario = Convert.ToInt32(Grid.SelectedCells[2].Value.ToString());
            if (e.ColumnIndex == this.Grid.Columns["Eliminar"].Index)
            {
                DialogResult result;
                result = MessageBox.Show("¿Desea eliminar el requistro?", "Eliminando registros", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if(result == DialogResult.OK)
                {
                    eliminar_usuarios();
                    mostrar_usuarios();
                }
            }
            if (e.ColumnIndex == this.Grid.Columns["Editar"].Index)
            {
                tLogin.Text = Grid.SelectedCells[3].Value.ToString();
                tPass.Text = Grid.SelectedCells[4].Value.ToString();
                Imagen.BackgroundImage = null;
                byte[] b = (Byte[])Grid.SelectedCells[5].Value;
                System.IO.MemoryStream ms = new System.IO.MemoryStream(b);
                Imagen.Image = Image.FromStream(ms);

                panelUsuario.Visible = true;
                panelUsuario.Dock = DockStyle.Fill;
                btnGuardar.Visible = false;
                btnAct.Visible = true;
            }
        }
        private void mostrar_usuarios()
        {
            DataTable dt;
            Dusers funcion = new Dusers();
            dt = funcion.mostrar_usuarios();
            Grid.DataSource = dt;
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            panelUsuario.Visible = false;
            panelUsuario.Dock = DockStyle.None;
        }

        private void editar_usuario()
        {
            Lusers dt = new Lusers();
            Dusers funcion = new Dusers();
            dt.Idusuario = idusuario;
            dt.Usuario = tLogin.Text;
            dt.Pass = tPass.Text;
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            Imagen.Image.Save(ms, Imagen.Image.RawFormat);
            dt.Icono = ms.GetBuffer();
            dt.Estado = "ACTIVO";
            if (funcion.editar(dt))
            {
                MessageBox.Show("Usuario Modificado", "Registro Correcto");
                panelUsuario.Visible = false;
                panelUsuario.Dock = DockStyle.None;
            }
        }

        private void btnAct_Click(object sender, EventArgs e)
        {
            editar_usuario();
            mostrar_usuarios();
        }
    }
}
