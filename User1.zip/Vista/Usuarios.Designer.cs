﻿namespace User1.Vista
{
    partial class Usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Div = new System.Windows.Forms.Panel();
            this.bAgregar = new System.Windows.Forms.Button();
            this.pBusqueda = new System.Windows.Forms.PictureBox();
            this.Line = new System.Windows.Forms.Panel();
            this.tBusqueda = new System.Windows.Forms.TextBox();
            this.barraName = new System.Windows.Forms.Label();
            this.Grid = new System.Windows.Forms.DataGridView();
            this.panelUsuario = new System.Windows.Forms.Panel();
            this.lImage = new System.Windows.Forms.Label();
            this.lPass = new System.Windows.Forms.Label();
            this.lLogin = new System.Windows.Forms.Label();
            this.btnVolver = new System.Windows.Forms.Button();
            this.btnAct = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.tLogin = new System.Windows.Forms.TextBox();
            this.Imagen = new System.Windows.Forms.PictureBox();
            this.dlg = new System.Windows.Forms.OpenFileDialog();
            this.tPass = new System.Windows.Forms.TextBox();
            this.Eliminar = new System.Windows.Forms.DataGridViewImageColumn();
            this.Editar = new System.Windows.Forms.DataGridViewImageColumn();
            this.panel1.SuspendLayout();
            this.Div.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBusqueda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Grid)).BeginInit();
            this.panelUsuario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Imagen)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Div);
            this.panel1.Controls.Add(this.barraName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(860, 91);
            this.panel1.TabIndex = 0;
            // 
            // Div
            // 
            this.Div.BackColor = System.Drawing.Color.White;
            this.Div.Controls.Add(this.bAgregar);
            this.Div.Controls.Add(this.pBusqueda);
            this.Div.Controls.Add(this.Line);
            this.Div.Controls.Add(this.tBusqueda);
            this.Div.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Div.Location = new System.Drawing.Point(0, 38);
            this.Div.Name = "Div";
            this.Div.Size = new System.Drawing.Size(860, 53);
            this.Div.TabIndex = 1;
            // 
            // bAgregar
            // 
            this.bAgregar.BackColor = System.Drawing.SystemColors.Highlight;
            this.bAgregar.FlatAppearance.BorderSize = 0;
            this.bAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bAgregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bAgregar.ForeColor = System.Drawing.Color.White;
            this.bAgregar.Location = new System.Drawing.Point(346, 13);
            this.bAgregar.Name = "bAgregar";
            this.bAgregar.Size = new System.Drawing.Size(75, 26);
            this.bAgregar.TabIndex = 3;
            this.bAgregar.Text = "Agregar";
            this.bAgregar.UseVisualStyleBackColor = false;
            this.bAgregar.Click += new System.EventHandler(this.button1_Click);
            // 
            // pBusqueda
            // 
            this.pBusqueda.Image = global::User1.Properties.Resources.buscar;
            this.pBusqueda.Location = new System.Drawing.Point(306, 14);
            this.pBusqueda.Name = "pBusqueda";
            this.pBusqueda.Size = new System.Drawing.Size(25, 24);
            this.pBusqueda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBusqueda.TabIndex = 2;
            this.pBusqueda.TabStop = false;
            // 
            // Line
            // 
            this.Line.BackColor = System.Drawing.SystemColors.Highlight;
            this.Line.Location = new System.Drawing.Point(30, 37);
            this.Line.Name = "Line";
            this.Line.Size = new System.Drawing.Size(276, 1);
            this.Line.TabIndex = 1;
            // 
            // tBusqueda
            // 
            this.tBusqueda.Location = new System.Drawing.Point(30, 15);
            this.tBusqueda.Name = "tBusqueda";
            this.tBusqueda.Size = new System.Drawing.Size(276, 20);
            this.tBusqueda.TabIndex = 0;
            this.tBusqueda.TextChanged += new System.EventHandler(this.tBusqueda_TextChanged);
            // 
            // barraName
            // 
            this.barraName.BackColor = System.Drawing.SystemColors.Highlight;
            this.barraName.Dock = System.Windows.Forms.DockStyle.Top;
            this.barraName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.barraName.ForeColor = System.Drawing.Color.White;
            this.barraName.Location = new System.Drawing.Point(0, 0);
            this.barraName.Name = "barraName";
            this.barraName.Size = new System.Drawing.Size(860, 38);
            this.barraName.TabIndex = 0;
            this.barraName.Text = "Usuarios";
            this.barraName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.barraName.Click += new System.EventHandler(this.label1_Click);
            // 
            // Grid
            // 
            this.Grid.AllowUserToAddRows = false;
            this.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Eliminar,
            this.Editar});
            this.Grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Grid.Location = new System.Drawing.Point(0, 91);
            this.Grid.Name = "Grid";
            this.Grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Grid.Size = new System.Drawing.Size(860, 453);
            this.Grid.TabIndex = 1;
            this.Grid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Grid_CellContentClick);
            this.Grid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Grid_CellContentClick);
            // 
            // panelUsuario
            // 
            this.panelUsuario.BackColor = System.Drawing.Color.White;
            this.panelUsuario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panelUsuario.Controls.Add(this.lImage);
            this.panelUsuario.Controls.Add(this.lPass);
            this.panelUsuario.Controls.Add(this.lLogin);
            this.panelUsuario.Controls.Add(this.btnVolver);
            this.panelUsuario.Controls.Add(this.btnAct);
            this.panelUsuario.Controls.Add(this.btnGuardar);
            this.panelUsuario.Controls.Add(this.tLogin);
            this.panelUsuario.Controls.Add(this.Imagen);
            this.panelUsuario.Controls.Add(this.tPass);
            this.panelUsuario.Location = new System.Drawing.Point(159, 97);
            this.panelUsuario.Name = "panelUsuario";
            this.panelUsuario.Size = new System.Drawing.Size(301, 402);
            this.panelUsuario.TabIndex = 2;
            this.panelUsuario.Visible = false;
            this.panelUsuario.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // lImage
            // 
            this.lImage.AutoSize = true;
            this.lImage.BackColor = System.Drawing.Color.White;
            this.lImage.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lImage.Location = new System.Drawing.Point(110, 94);
            this.lImage.Name = "lImage";
            this.lImage.Size = new System.Drawing.Size(76, 13);
            this.lImage.TabIndex = 3;
            this.lImage.Text = "Nueva imagen";
            // 
            // lPass
            // 
            this.lPass.AutoSize = true;
            this.lPass.BackColor = System.Drawing.Color.LightGray;
            this.lPass.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lPass.Location = new System.Drawing.Point(124, 272);
            this.lPass.Name = "lPass";
            this.lPass.Size = new System.Drawing.Size(52, 13);
            this.lPass.TabIndex = 3;
            this.lPass.Text = "password";
            this.lPass.Click += new System.EventHandler(this.lPass_Click);
            // 
            // lLogin
            // 
            this.lLogin.AutoSize = true;
            this.lLogin.BackColor = System.Drawing.Color.LightGray;
            this.lLogin.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lLogin.Location = new System.Drawing.Point(136, 234);
            this.lLogin.Name = "lLogin";
            this.lLogin.Size = new System.Drawing.Size(29, 13);
            this.lLogin.TabIndex = 3;
            this.lLogin.Text = "login";
            this.lLogin.Click += new System.EventHandler(this.lLogin_Click);
            // 
            // btnVolver
            // 
            this.btnVolver.BackColor = System.Drawing.Color.LightBlue;
            this.btnVolver.FlatAppearance.BorderSize = 0;
            this.btnVolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolver.Location = new System.Drawing.Point(194, 343);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(75, 23);
            this.btnVolver.TabIndex = 2;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = false;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // btnAct
            // 
            this.btnAct.BackColor = System.Drawing.Color.LightBlue;
            this.btnAct.FlatAppearance.BorderSize = 0;
            this.btnAct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAct.Location = new System.Drawing.Point(113, 343);
            this.btnAct.Name = "btnAct";
            this.btnAct.Size = new System.Drawing.Size(75, 23);
            this.btnAct.TabIndex = 2;
            this.btnAct.Text = "Actualizar";
            this.btnAct.UseVisualStyleBackColor = false;
            this.btnAct.Click += new System.EventHandler(this.btnAct_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.LightBlue;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Location = new System.Drawing.Point(32, 343);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 2;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // tLogin
            // 
            this.tLogin.AccessibleName = "";
            this.tLogin.BackColor = System.Drawing.Color.LightGray;
            this.tLogin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tLogin.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tLogin.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tLogin.Location = new System.Drawing.Point(65, 225);
            this.tLogin.MaximumSize = new System.Drawing.Size(200, 30);
            this.tLogin.Multiline = true;
            this.tLogin.Name = "tLogin";
            this.tLogin.Size = new System.Drawing.Size(171, 30);
            this.tLogin.TabIndex = 1;
            this.tLogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tLogin.TextChanged += new System.EventHandler(this.Usuario_TextChanged);
            // 
            // Imagen
            // 
            this.Imagen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Imagen.Location = new System.Drawing.Point(100, 43);
            this.Imagen.Name = "Imagen";
            this.Imagen.Size = new System.Drawing.Size(98, 135);
            this.Imagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Imagen.TabIndex = 0;
            this.Imagen.TabStop = false;
            this.Imagen.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // dlg
            // 
            this.dlg.FileName = "openFileDialog1";
            // 
            // tPass
            // 
            this.tPass.BackColor = System.Drawing.Color.LightGray;
            this.tPass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tPass.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tPass.Location = new System.Drawing.Point(65, 265);
            this.tPass.Multiline = true;
            this.tPass.Name = "tPass";
            this.tPass.Size = new System.Drawing.Size(171, 30);
            this.tPass.TabIndex = 4;
            this.tPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tPass.TextChanged += new System.EventHandler(this.tPass_TextChanged);
            // 
            // Eliminar
            // 
            this.Eliminar.HeaderText = "Eliminar";
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Eliminar.Width = 50;
            // 
            // Editar
            // 
            this.Editar.HeaderText = "Editar";
            this.Editar.Name = "Editar";
            this.Editar.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Editar.Width = 40;
            // 
            // Usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(860, 544);
            this.Controls.Add(this.panelUsuario);
            this.Controls.Add(this.Grid);
            this.Controls.Add(this.panel1);
            this.Name = "Usuarios";
            this.Text = "Usuarios";
            this.Load += new System.EventHandler(this.Usuarios_Load);
            this.panel1.ResumeLayout(false);
            this.Div.ResumeLayout(false);
            this.Div.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBusqueda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Grid)).EndInit();
            this.panelUsuario.ResumeLayout(false);
            this.panelUsuario.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Imagen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label barraName;
        private System.Windows.Forms.Panel Div;
        private System.Windows.Forms.PictureBox pBusqueda;
        private System.Windows.Forms.Panel Line;
        private System.Windows.Forms.TextBox tBusqueda;
        private System.Windows.Forms.Button bAgregar;
        private System.Windows.Forms.DataGridView Grid;
        private System.Windows.Forms.Panel panelUsuario;
        private System.Windows.Forms.TextBox tLogin;
        private System.Windows.Forms.PictureBox Imagen;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.Button btnAct;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.OpenFileDialog dlg;
        private System.Windows.Forms.Label lPass;
        private System.Windows.Forms.Label lLogin;
        private System.Windows.Forms.Label lImage;
        private System.Windows.Forms.TextBox tPass;
        private System.Windows.Forms.DataGridViewImageColumn Eliminar;
        private System.Windows.Forms.DataGridViewImageColumn Editar;
    }
}